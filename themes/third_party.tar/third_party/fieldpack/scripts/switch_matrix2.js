(function($) {


Matrix.bind('fieldpack_switch', 'display', function(cell){
	new ptSwitch($('select', this));
});


})(jQuery);
