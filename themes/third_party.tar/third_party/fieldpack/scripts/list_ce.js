(function($) {


ContentElements.bind('fieldpack_list', 'display', function(element){
   	new ptList($('ul', element));
});


})(jQuery);
