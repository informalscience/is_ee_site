(function($) {


Matrix.bind('fieldpack_list', 'display', function(cell){
	new ptList($('ul', this));
});


})(jQuery);
